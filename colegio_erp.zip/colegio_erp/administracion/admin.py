from django.contrib import admin
from .models import Estudiante, Pago

admin.site.register(Estudiante)
admin.site.register(Pago)
