from django.db import models

class Estudiante(models.Model):
    nombre = models.CharField(max_length=255)
    matricula = models.CharField(max_length=50)
    fecha_inscripcion = models.DateField()

class Pago(models.Model):
    estudiante = models.ForeignKey(Estudiante, on_delete=models.CASCADE)
    fecha = models.DateField()
    monto = models.DecimalField(max_digits=10, decimal_places=2)
