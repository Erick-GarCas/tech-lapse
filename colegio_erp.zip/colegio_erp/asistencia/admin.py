from django.contrib import admin
from .models import Docente, Asistencia

admin.site.register(Docente)
admin.site.register(Asistencia)
    