from django.db import models

class Docente(models.Model):
    nombre = models.CharField(max_length=255)
    email = models.EmailField()

class Asistencia(models.Model):
    docente = models.ForeignKey(Docente, on_delete=models.CASCADE)
    fecha = models.DateField()
    presente = models.BooleanField(default=True)
