from django.db import models

class Material(models.Model):
    nombre = models.CharField(max_length=255)
    cantidad = models.IntegerField()
    fecha_ingreso = models.DateField()

class Movimiento(models.Model):
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    cantidad = models.IntegerField()
    tipo = models.CharField(max_length=50, choices=[('entrada', 'Entrada'), ('salida', 'Salida')])
    fecha = models.DateField()
