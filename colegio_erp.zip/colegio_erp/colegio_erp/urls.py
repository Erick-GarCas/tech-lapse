from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('contabilidad/', include('contabilidad.urls')),
    path('inventarios/', include('inventarios.urls')),
    path('asistencia/', include('asistencia.urls')),
    path('nomina/', include('nomina.urls')),
    path('administracion/', include('administracion.urls')),
]
