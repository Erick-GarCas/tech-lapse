from django.contrib import admin
from .models import Ingreso, Egreso, Balance

admin.site.register(Ingreso)
admin.site.register(Egreso)
admin.site.register(Balance)
