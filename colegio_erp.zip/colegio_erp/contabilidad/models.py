from django.db import models

class Ingreso(models.Model):
    fecha = models.DateField()
    descripcion = models.CharField(max_length=255)
    monto = models.DecimalField(max_digits=10, decimal_places=2)

class Egreso(models.Model):
    fecha = models.DateField()
    descripcion = models.CharField(max_length=255)
    monto = models.DecimalField(max_digits=10, decimal_places=2)

class Balance(models.Model):
    fecha = models.DateField()
    total_ingresos = models.DecimalField(max_digits=10, decimal_places=2)
    total_egresos = models.DecimalField(max_digits=10, decimal_places=2)
    balance_neto = models.DecimalField(max_digits=10, decimal_places=2)
