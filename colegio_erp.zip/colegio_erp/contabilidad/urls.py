from django.urls import path
from . import views

urlpatterns = [
    path('ingresos/', views.lista_ingresos, name='lista_ingresos'),
    path('egresos/', views.lista_egresos, name='lista_egresos'),
]
