from django.shortcuts import render
from .models import Ingreso, Egreso

def lista_ingresos(request):
    ingresos = Ingreso.objects.all()
    return render(request, 'contabilidad/ingresos.html', {'ingresos': ingresos})

def lista_egresos(request):
    egresos = Egreso.objects.all()
    return render(request, 'contabilidad/egresos.html', {'egresos': egresos})
