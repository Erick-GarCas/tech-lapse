from django.contrib import admin
from .models import Material, Movimiento

admin.site.register(Material)
admin.site.register(Movimiento)
