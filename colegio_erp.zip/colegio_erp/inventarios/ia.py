import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

def entrenar_modelo_consumo(inventario_df):
    X = inventario_df[['mes']].values  # Variable temporal (mes)
    y = inventario_df['cantidad'].values  # Cantidad de material consumido

    modelo = Sequential()
    modelo.add(Dense(64, activation='relu', input_dim=1))
    modelo.add(Dense(64, activation='relu'))
    modelo.add(Dense(1, activation='linear'))

    modelo.compile(optimizer='adam', loss='mean_squared_error')

    modelo.fit(X, y, epochs=10, batch_size=32)
    return modelo
