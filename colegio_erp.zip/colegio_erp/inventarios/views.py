from .ia import entrenar_modelo_consumo
from .models import Material
import pandas as pd

def predecir_consumo_materiales(request):
    materiales = Material.objects.all()
    df_materiales = pd.DataFrame(list(materiales.values()))

    modelo = entrenar_modelo_consumo(df_materiales)
    prediccion = modelo.predict([[12]])  # Predecir para el mes 12

    return render(request, 'inventarios/prediccion.html', {'prediccion': prediccion})
