from django.db import models
from asistencia.models import Docente

class Nomina(models.Model):
    docente = models.ForeignKey(Docente, on_delete=models.CASCADE)
    mes = models.DateField()
    salario_base = models.DecimalField(max_digits=10, decimal_places=2)
    deducciones = models.DecimalField(max_digits=10, decimal_places=2, default=0.0)
    salario_neto = models.DecimalField(max_digits=10, decimal_places=2)
